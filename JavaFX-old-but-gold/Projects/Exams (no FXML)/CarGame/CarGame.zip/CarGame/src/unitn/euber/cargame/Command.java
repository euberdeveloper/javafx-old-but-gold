/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unitn.euber.cargame;

/**
 * The enumeration of the command sent by the car controller
 * @author Eugenio Vinicio Berretta
 */
public enum Command {
    TOP, BOTTOM, RIGHT, LEFT, RANDOM, START, STOP
}
