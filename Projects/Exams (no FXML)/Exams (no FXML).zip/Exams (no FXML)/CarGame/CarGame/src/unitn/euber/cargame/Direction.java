package unitn.euber.cargame;

/**
 * The enumeration of the four directions
 * @author Eugenio Vinicio Berretta
 */
public enum Direction {
    TOP, BOTTOM, RIGHT, LEFT
}
